const getConfig = () => {
    return {
        app: {
            
        },
        mailer: {

        },
        token: {

        }
    }
}

module.exports = {
    getConfig
}